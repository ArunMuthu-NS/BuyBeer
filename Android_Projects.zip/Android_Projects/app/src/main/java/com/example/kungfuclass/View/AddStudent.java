package com.example.kungfuclass.View;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.kungfuclass.Controller.MainController;
import com.example.kungfuclass.R;

import org.json.JSONException;
import org.json.JSONObject;

public class AddStudent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);
    }

    public void addStudent(View view){
        try {
            EditText name = (EditText) findViewById(R.id.nameText);
            EditText address = (EditText) findViewById(R.id.addressText);
            EditText contact = (EditText) findViewById(R.id.contactText);
            EditText bloodGroup = (EditText) findViewById(R.id.bloodGroupText);

            JSONObject studentData = new JSONObject();
            studentData.put("name", name.getText().toString());
            studentData.put("address", address.getText().toString());
            studentData.put("contact", contact.getText().toString());
            studentData.put("bloodGroup", bloodGroup.getText().toString());

            MainController.getInstance(this).addStudent(studentData);
        }
        catch(JSONException ex){
            Log.d("Error while Adding Data","" + ex);
        }
    }
}
