package com.example.kungfuclass.DBUtil;

import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

import com.example.kungfuclass.Model.TestDetails;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BeltTestModule {
    SQLiteInteraction interactor = null;

    public BeltTestModule(SQLiteInteraction interactor) {
        this.interactor = interactor;
    }

    public void createBeltTest(JSONObject testData){
        try {
            ContentValues row = new ContentValues();
            row.put("LOCATION", testData.get("LOCATION").toString());
            row.put("DATE", testData.get("DATE").toString());
            long testid = interactor.writeDB.insert("BELT_TEST", null, row);
            Log.d("Belt Test ID ", "" + testid);
        }
        catch(Exception e){
            Log.d("Exception while",e.getMessage());
        }
    }

    public void updateBeltDetails(){

    }

    public List<TestDetails> getTestDetails(){
        List<TestDetails> list = new ArrayList<TestDetails>();
        Cursor cursor = interactor.readDB.query("BELT_TEST",null,null,null,null,null,null);
        if (cursor.moveToFirst()) {
            Log.d("Coming ","Lets see");
            do {
                TestDetails testDetails = new TestDetails();
                testDetails.setTestId(cursor.getInt(0));
                testDetails.setDate(cursor.getString(1));
                testDetails.setLocation(cursor.getString(2));
                list.add(testDetails);
            } while (cursor.moveToNext());
        }

        Log.d("Test Details","List Sie " + list.size());
        return list;
    }
}
