package com.example.kungfuclass.DBUtil;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class SQLiteInteraction extends SQLiteOpenHelper {

    static String DB_NAME = "Kung_Fu_Class.DB";
    static Integer version = 1;

    protected SQLiteDatabase writeDB = null,readDB = null;

    private final String createTableConstraint = "CREATE TABLE IF NOT EXISTS ";

    private final String tables[] = new String[]{
            createTableConstraint + "STUDENTS (STUDENT_ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT NOT NULL,ADDRESS TEXT,CONTACT TEXT NOT NULL,BLOOD_GROUP TEXT,STATUS DEFAULT 1)",
            createTableConstraint + "BELT_TEST (TEST_ID INTEGER PRIMARY KEY AUTOINCREMENT, LOCATION TEXT NOT NULL, DATE TEXT NOT NULL)",
            createTableConstraint + "PARTICIPANTS(TEST_ID INTEGER NOT NULL, STUDENT_ID INTEGER NOT NULL,BELT_COLOR TEXT NOT NULL,RESULT TEXT DEFAULT NA )",
    };

    public SQLiteInteraction(Context context){
        super(context,DB_NAME,null,1);
        writeDB = this.getWritableDatabase();
        readDB = this.getReadableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.d("Added","Deleted");

        for(String query : tables)
            sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addTable(){
        for(String query : tables)
            writeDB.execSQL(query);
    }

    public void deleteTable(){
        writeDB.execSQL("DROP TABLE STUDENTS");
        writeDB.execSQL("DROP TABLE BELT_TEST");
        writeDB.execSQL("DROP TABLE PARTICIPANTS");
    }

    public void close(){
        writeDB.close();
        readDB.close();
    }
}
