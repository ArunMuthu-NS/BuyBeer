package com.example.kungfuclass.Model;

public class TestDetails {
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setDate(String date) {
        this.date = date;
    }

    private String location;
    private String date;

    public int getTestId() {
        return testId;
    }

    public void setTestId(int testId) {
        this.testId = testId;
    }

    private int testId;

    public String getDate() {
        return date;
    }
}
