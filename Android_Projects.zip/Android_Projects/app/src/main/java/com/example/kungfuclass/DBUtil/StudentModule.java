package com.example.kungfuclass.DBUtil;

import android.content.ContentValues;
import android.util.Log;

import org.json.JSONObject;

public class StudentModule{
    SQLiteInteraction interactor = null;

    public StudentModule(SQLiteInteraction interactor) {
        this.interactor = interactor;
    }

    public void addStudent(JSONObject studentData){
        interactor.deleteTable();
        interactor.addTable();

        ContentValues values = new ContentValues();
        values.put("NAME", studentData.optString("name",null));
        values.put("ADDRESS", studentData.optString("address",null));
        values.put("CONTACT", studentData.optString("contact",null));
        values.put("BLOOD_GROUP", studentData.optString("bloodGroup",null));

        // Inserting Row
        long id =  interactor.writeDB.insert("STUDENTS", null, values);
        Log.d("Via Activity" , ""+id);
    }

    public void editStudent(){

    }

    public void changeStatus(){

    }
}