package com.example.kungfuclass.Controller;

import android.content.Context;

import com.example.kungfuclass.DBUtil.BeltTestModule;
import com.example.kungfuclass.DBUtil.SQLiteInteraction;
import com.example.kungfuclass.DBUtil.StudentHistoryModule;
import com.example.kungfuclass.DBUtil.StudentModule;
import com.example.kungfuclass.Model.Student;
import com.example.kungfuclass.Model.TestDetails;

import org.json.JSONObject;

import java.util.List;

public class MainController {

    private static MainController mainController = null;
    private SQLiteInteraction interactor = null;

    public static MainController getInstance(Context context){
        if(mainController == null)
            mainController = new MainController(context);
        return mainController;
    }

    MainController(Context context){
        interactor = new SQLiteInteraction(context);
    }

    public void addStudent(JSONObject studentData){
        StudentModule sm = new StudentModule(interactor);
        sm.addStudent(studentData);
    }

    public void createBeltTest(JSONObject testData){
        BeltTestModule btm = new BeltTestModule(interactor);
        btm.createBeltTest(testData);
    }

    public List<Student> showStudents(){
        return new StudentHistoryModule(interactor).showStudents();
    }

    public List<TestDetails> getTestDetails(){
        return new BeltTestModule(interactor).getTestDetails();
    }
}
