package com.example.kungfuclass;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.kungfuclass.DBUtil.SQLiteInteraction;
import com.example.kungfuclass.View.AddStudent;
import com.example.kungfuclass.View.BeltTestDetails;
import com.example.kungfuclass.View.CreateBeltTest;
import com.example.kungfuclass.View.StudentProgress;

public class Home extends AppCompatActivity {
    private SQLiteInteraction interactor = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void addStudent(View view){
        Intent intent = new Intent(this,AddStudent.class);
        startActivity(intent);
    }

    public void showStudentsProgress(View view){
        Intent intent = new Intent(this, StudentProgress.class);
        startActivity(intent);
    }

    public void createBeltTest(View view){
        Intent intent = new Intent(this, CreateBeltTest.class);
        startActivity(intent);
    }

    public void viewBeltTestDetails(View view){
        Intent intent = new Intent(this, BeltTestDetails.class);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        interactor.close();
    }
}
