package com.example.kungfuclass.DBUtil;

import android.database.Cursor;
import android.util.Log;

import com.example.kungfuclass.Model.Student;

import java.util.ArrayList;
import java.util.List;

public class StudentHistoryModule {
    SQLiteInteraction interactor = null;

    public StudentHistoryModule(SQLiteInteraction interactor){
        this.interactor = interactor;
    }

    public List<Student> showStudents(){
        ArrayList<Student> list = new ArrayList<Student>();
        Cursor cursor = interactor.readDB.query("STUDENTS",null,null,null,null,null,null);
        Log.d("This is so hard","How to do it");
        if (cursor.moveToFirst()) {
            Log.d("Coming ","Lets see");
            do {
                Student student = new Student();
                student.setName(cursor.getString(1));
                student.setAddress(cursor.getString(2));
                student.setBloodGroup(cursor.getString(3));
                student.setContact(cursor.getString(4));
                list.add(student);
            } while (cursor.moveToNext());
        }
        Log.d("After Getting Students","Curious To Develop");
        return list;
    }

    public void filterStudent(){

    }

    public void viewStudentProgress(){

    }
}
