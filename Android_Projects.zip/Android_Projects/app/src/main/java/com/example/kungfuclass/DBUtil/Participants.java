package com.example.kungfuclass.DBUtil;

import android.content.ContentValues;
import android.util.Log;

public class Participants {

    SQLiteInteraction interactor;

    public Participants(SQLiteInteraction interactor){
        this.interactor = interactor;
    }

    public void addParticipant(){
        ContentValues row = new ContentValues();
        row.put("TEST_ID",1);
        row.put("STUDENT_ID",2);
        row.put("BELT_COLOR","GREEN");
        long users = interactor.writeDB.insert("PARTICIPANTS",null,row);
        Log.d("USER ID ",""+users);
    }

    public void updateResult(){

    }

    public void removeParticipant(){

    }
}