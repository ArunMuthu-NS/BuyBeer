package com.example.kungfuclass.View;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.kungfuclass.Controller.MainController;
import com.example.kungfuclass.Model.Student;
import com.example.kungfuclass.R;

import java.util.List;

public class StudentProgress extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_progress);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        List<Student> list = MainController.getInstance(this).showStudents();

        ListView studentListView = (ListView) findViewById(R.id.studentsList);
        Log.d("\n\n\nArun Kumar ",""+list.size()+" "+list);
        studentListView.setAdapter(new listAdapter(this,R.layout.row_item,list));
    }

    class listAdapter extends BaseAdapter{

        List<Student> list = null;
        Context context = null;

        public listAdapter(@NonNull Context context, int resource,List<Student> students) {
            this.context = context;
            this.list = students;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return list.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.row_item,parent,false);
            TextView tv = (TextView) convertView.findViewById(R.id.textView);
            Log.d("\n\nSample Text",""+ list.get(position).getName());
            tv.setText(list.get(position).getName());
            return convertView;
        }
    }

}
